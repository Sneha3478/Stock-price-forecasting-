# -*- coding: utf-8 -*-
"""
Created on Sun May 25 03:58:42 2025

@author: Sneha
"""
import pandas as pd
import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")


# Show first 5 rows# Show all column names
print(df.columns)

# Show the first few rows
print(df.head())
# Drop the 'Adj Close' column from the dataset
df.drop(columns='Adj Close', inplace=True)

# Check the updated DataFrame
print(df.head())


print(df.head())



import matplotlib.pyplot as plt

plt.figure(figsize=(12,6))
plt.plot(df['Close'], label='Close Price')
plt.title('Stock Close Price Over Time')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.show()

plt.figure(figsize=(12,6))
plt.plot(df['Volume'], color='orange', label='Volume')
plt.title('Stock Trading Volume Over Time')
plt.xlabel('Date')
plt.ylabel('Volume')
plt.legend()
plt.show()


df['Daily Return'] = df['Close'].pct_change()

plt.figure(figsize=(12,6))
plt.plot(df['Daily Return'], label='Daily Return')
plt.title('Daily Returns Over Time')
plt.xlabel('Date')
plt.ylabel('Return')
plt.legend()
plt.show()
