# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:32:35 2025

@author: Sneha
"""

# prophet_model.py

import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt

# Step 1: Load your actual dataset
df = pd.read_csv('yahoo_stock.csv', parse_dates=['Date'])

# Step 2: Rename columns for Prophet
# Prophet expects: 'ds' for date and 'y' for target
df_prophet = df[['Date', 'Close']].rename(columns={'Date': 'ds', 'Close': 'y'})

# Step 3: Initialize and fit Prophet model
model = Prophet()
model.fit(df_prophet)

# Step 4: Create a dataframe for future predictions (next 30 days)
future = model.make_future_dataframe(periods=30)

# Step 5: Forecast future values
forecast = model.predict(future)

# Step 6: Plot the forecast
model.plot(forecast)
plt.title("Forecast of Closing Price using Prophet")
plt.xlabel("Date")
plt.ylabel("Price")
plt.grid(True)
plt.show()

# Optional: Show forecast components (trend, seasonality, etc.)
model.plot_components(forecast)
plt.show()
