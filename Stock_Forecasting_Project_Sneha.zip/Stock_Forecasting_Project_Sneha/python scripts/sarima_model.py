# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:24:34 2025

@author: Sneha
"""
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt



# Define SARIMA parameters (example)
order = (1, 1, 1)
seasonal_order = (1, 1, 1, 12)  # seasonality of 12 months if monthly data

import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")


sarima_model = sm.tsa.statespace.SARIMAX(df['Close'],
                                        order=order,
                                        seasonal_order=seasonal_order)
sarima_result = sarima_model.fit()

print(sarima_result.summary())

# Forecast 30 steps
sarima_forecast = sarima_result.get_forecast(steps=30)
mean_forecast = sarima_forecast.predicted_mean
conf_int = sarima_forecast.conf_int()

plt.figure(figsize=(12,6))
plt.plot(df.index, df['Close'], label='Historical Close Price')
plt.plot(mean_forecast.index, mean_forecast, label='SARIMA Forecast')
plt.fill_between(mean_forecast.index, conf_int.iloc[:, 0], conf_int.iloc[:, 1], color='lightblue', alpha=0.3)
plt.title('SARIMA Forecast')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.legend()
plt.show()
