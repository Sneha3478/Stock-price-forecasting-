# -*- coding: utf-8 -*-
"""
Created on Sun May 25 08:06:33 2025

@author: Sneha
"""

# sarima_model.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Load data
df = pd.read_csv('yahoo_stock.csv', parse_dates=['Date'])
df = df[['Date', 'Close']].dropna()
df = df.sort_values('Date')
df.set_index('Date', inplace=True)

# Split data into train and test (last 30 days for test)
train = df.iloc[:-30]
test = df.iloc[-30:]

# Fit SARIMA model
model = SARIMAX(train['Close'],
                order=(1, 1, 1),
                seasonal_order=(1, 1, 1, 12),
                enforce_stationarity=False,
                enforce_invertibility=False)

sarima_result = model.fit(disp=False)

# Forecast for next 30 days
forecast = sarima_result.forecast(steps=30)
forecast.index = test.index

# Calculate accuracy metrics
mae = mean_absolute_error(test['Close'], forecast)
rmse = np.sqrt(mean_squared_error(test['Close'], forecast))
mape = np.mean(np.abs((test['Close'] - forecast) / test['Close'])) * 100

print(f"\n📊 SARIMA Forecast Accuracy (Last 30 Days):")
print(f"MAE: {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"MAPE: {mape:.2f}%")

# Plot forecast vs actual
plt.figure(figsize=(12, 6))
plt.plot(train.index[-30:], train['Close'][-30:], label='Train')
plt.plot(test.index, test['Close'], label='Actual', marker='o')
plt.plot(forecast.index, forecast, label='Forecast (SARIMA)', marker='x')
plt.title('SARIMA Model: Actual vs Forecast (Last 30 Days)')
plt.xlabel('Date')
plt.ylabel('Stock Price')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
