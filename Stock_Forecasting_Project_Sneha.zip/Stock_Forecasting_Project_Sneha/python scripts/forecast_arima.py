# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:05:43 2025

@author: Sneha
"""
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA


import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")

# Make sure to use the differenced 'Close' if needed (skip if already differenced)
# df['Close_diff'] = df['Close'].diff().dropna()

# Fit the ARIMA model
model = ARIMA(df['Close'], order=(1, 1, 1))
fitted_model = model.fit()

# Forecast next 30 days using the fitted model
forecast = fitted_model.get_forecast(steps=30)
predicted_mean = forecast.predicted_mean
conf_int = forecast.conf_int()

# Plot forecast
plt.figure(figsize=(12,6))
plt.plot(df['Close'], label='Historical')
plt.plot(predicted_mean.index, predicted_mean, label='Forecast', color='red')
plt.fill_between(predicted_mean.index,
                 conf_int.iloc[:, 0],
                 conf_int.iloc[:, 1], color='pink', alpha=0.3)
plt.title("ARIMA Forecast - Next 30 Days")
plt.xlabel("Date")
plt.ylabel("Close Price")
plt.legend()
plt.show()