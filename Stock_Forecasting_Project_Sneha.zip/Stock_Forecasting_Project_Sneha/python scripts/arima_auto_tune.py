# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:22:04 2025

@author: Sneha
"""

import pandas as pd
from pmdarima import auto_arima
import matplotlib.pyplot as plt

# Assuming your dataframe is loaded and indexed by date with 'Close' column
# df = pd.read_csv('your_file.csv', index_col='Date', parse_dates=True)
import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")

# Use auto_arima to find the best p, d, q
auto_model = auto_arima(df['Close'], seasonal=False, trace=True,
                        error_action='ignore', suppress_warnings=True)

print(auto_model.summary())

# Fit the model with the best parameters found
best_arima_model = auto_model.fit(df['Close'])

# Forecast next 30 days
forecast, conf_int = best_arima_model.predict(n_periods=30, return_conf_int=True)

# Plot the forecast
plt.figure(figsize=(12,6))
plt.plot(df.index, df['Close'], label='Historical Close Price')
forecast_index = pd.date_range(df.index[-1], periods=30, freq='D')
plt.plot(forecast_index, forecast, label='Forecast')
plt.fill_between(forecast_index, conf_int[:, 0], conf_int[:, 1], color='pink', alpha=0.3)
plt.title('ARIMA Forecast with Auto-tuned Parameters')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.legend()
plt.show()
