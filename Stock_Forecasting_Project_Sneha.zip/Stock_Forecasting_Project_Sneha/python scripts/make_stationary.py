# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:00:23 2025

@author: Sneha
"""

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller

import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")


# Apply first-order differencing
df_diff = df['Close'].diff().dropna()

# Plot differenced data
plt.figure(figsize=(12,6))
plt.plot(df_diff, label='Differenced Close Price')
plt.title('Differenced Close Price (1st Order)')
plt.xlabel('Date')
plt.ylabel('Price Change')
plt.legend()
plt.show()

# ADF Test again
result = adfuller(df_diff)
print("ADF Statistic:", result[0])
print("p-value:", result[1])
print("Critical Values:")
for key, value in result[4].items():
    print(f'\t{key}: {value}')
