# -*- coding: utf-8 -*-
"""
Created on Sun May 25 06:44:19 2025

@author: Sneha
"""

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")

# Decomposition
result = seasonal_decompose(df['Close'], model='multiplicative', period=30)

# Plot the decomposition
plt.rcParams.update({'figure.figsize': (10, 8)})
result.plot()
plt.suptitle('Time Series Decomposition (Close Price)', fontsize=16)
plt.show()
