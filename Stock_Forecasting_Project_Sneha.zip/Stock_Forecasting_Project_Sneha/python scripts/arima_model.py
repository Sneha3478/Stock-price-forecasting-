# -*- coding: utf-8 -*-
"""
Created on Sun May 25 07:02:59 2025

@author: Sneha
"""

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")

# Load data
df = pd.read_csv('yahoo_stock.csv', parse_dates=['Date'])
df = df.rename(columns={'Date': 'ds', 'Close': 'y'})
df = df.sort_values('ds')

print("Columns in DataFrame:", df.columns.tolist())


# Split train/test
train = df.iloc[:-30]
test = df.iloc[-30:]

# Train ARIMA model (replace order with your chosen parameters)
arima_model = ARIMA(train['y'], order=(5,1,0))  # example order
arima_model_fit = arima_model.fit()


# Differencing to make it stationary
df['y_diff'] = df['y'].diff()

df.dropna(inplace=True)

# Build ARIMA model (you can try (p,d,q) = (1,1,1) as a start)
model = ARIMA(df['y'], order=(1, 1, 1))
model_fit = model.fit()

# Summary of the model
print(model_fit.summary())

# Forecasting
forecast = model_fit.forecast(steps=30)  # Forecast next 30 days

# Forecast for next 30 days
forecast = arima_model_fit.forecast(steps=30)

# Prepare actual and predicted
actual = test['y'].values
predicted = forecast.values

# Calculate metrics
mae = mean_absolute_error(actual, predicted)
rmse = np.sqrt(mean_squared_error(actual, predicted))
mape = np.mean(np.abs((actual - predicted) / actual)) * 100

print(f"\n📊 ARIMA Forecast Accuracy (Last 30 Days):")
print(f"MAE: {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"MAPE: {mape:.2f}%")

# Plot actual vs predicted
plt.figure(figsize=(12,6))
plt.plot(test['ds'], actual, label='Actual', marker='o')
plt.plot(test['ds'], predicted, label='Predicted (ARIMA)', marker='x')
plt.title('ARIMA Model: Actual vs Forecast (Last 30 Days)')
plt.xlabel('Date')
plt.ylabel('Stock Price')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Plot forecast
plt.figure(figsize=(12,6))
plt.plot(df['y'], label='Historical')
plt.plot(forecast.index, forecast, label='Forecast', color='red')
plt.title('Stock Price Forecast with ARIMA')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.show()
