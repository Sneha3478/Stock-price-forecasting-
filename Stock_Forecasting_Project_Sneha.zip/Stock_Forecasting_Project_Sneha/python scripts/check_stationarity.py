# -*- coding: utf-8 -*-
"""
Created on Sun May 25 06:56:38 2025

@author: Sneha
"""

import pandas as pd
from statsmodels.tsa.stattools import adfuller

import os

# Set the correct path
path = r"C:\Users\Sneha\.cache\kagglehub\datasets\arashnic\time-series-forecasting-with-yahoo-stock-price\versions\3"

# Load the CSV with date parsing
df = pd.read_csv(os.path.join(path, "yahoo_stock.csv"), parse_dates=True, index_col="Date")


# ADF Test on 'Close' column
result = adfuller(df['Close'])

print("ADF Statistic:", result[0])
print("p-value:", result[1])
print("Critical Values:")
for key, value in result[4].items():
    print(f'\t{key}: {value}')
