# -*- coding: utf-8 -*-
"""
Created on Sun May 25 09:53:46 2025

@author: Sneha
"""

import pandas as pd

# Replace these values with your actual results
data = {
    'Model': ['ARIMA', 'SARIMA', 'Prophet'],
    'MAE': [105.76, 97.07, 123.45],       # Replace with actual values
    'RMSE': [118.36, 110.13, 145.67],     # Replace with actual values
    'MAPE': [3.05, 2.81, 3.21]            # Replace with actual values
}

df = pd.DataFrame(data)

# Export to CSV
df.to_csv('model_comparison.csv', index=False)

print("Comparison table saved as model_comparison.csv")
